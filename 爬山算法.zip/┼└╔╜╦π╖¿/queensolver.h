#ifndef QUEENSOLVER_H
#define QUEENSOLVER_H
#include <cstdlib>
#include <iostream>
#include <windows.h>
#include <stdio.h>
#include <cmath>
#include <time.h>
#include "queenstate.h"
#include <iostream>
class QueenSolver
{
public:
    QueenSolver(int size);
    ~QueenSolver();
    void solve();//����ĺ��� 
protected:
    int _size;

};

#endif // QUEENSOLVER_H
