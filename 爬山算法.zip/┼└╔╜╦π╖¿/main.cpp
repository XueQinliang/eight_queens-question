#include <iostream>
#include <stack>
#include "dfsqueensolver.h"

using namespace std;

int main()
{   
    cout<<"PLEASE ENTER A INTEGER REPRESENTING THE NUM OF QUEEN��";
    int num;
    cin>>num;
    QueenSolver solver(num);
    solver.solve();
    return 0;
}
