#include <iostream>
#include <stack>
#include "dfsqueensolver.h"

using namespace std;

int main()
{
    DFSQueenSolver solver(8);
    solver.solve();
    return 0;
}
