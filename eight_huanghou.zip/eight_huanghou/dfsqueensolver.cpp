#include "dfsqueensolver.h"
#include <stack>
#include <queue> 
#include <cstdlib>
#include <stdio.h>
#include "queenstate.h"
using namespace std;
DFSQueenSolver::DFSQueenSolver(int size):QueenSolver(size){
}
DFSQueenSolver::~DFSQueenSolver(){

}

void DFSQueenSolver::solve(){
    queue<QueenState> states;
    QueenState st0(this->_size);
    states.push(st0);

    while(!states.empty()){

        QueenState crntSt =	states.front();
        states.pop();
        if(crntSt.getCrntQueenNum()>=this->_size){
            crntSt.printState();
            continue;
        }
        int i = crntSt.getCrntQueenNum();
        for (int j=0;j<this->_size;j++){
           if(!crntSt.conflict(i,j)){
               QueenState newSt = crntSt;
               newSt.placeQueen(i,j);
               states.push(newSt);
           }
        }
    }
}
