#ifndef QUEENSTATE_H
#define QUEENSTATE_H

class QueenState
{
public:
    QueenState(int size);
    QueenState(const QueenState & st);
    void placeQueen(int i, int j);//将第i行的皇后放在第j列
    void printState();//打印状态内容
    int getCrntQueenNum();
    bool conflict(int i, int j);//在第i行j列放入一个新的皇后，是否与现有皇后冲突

    ~QueenState();
private:
    int _size;//棋盘大小，即最多有多少皇后
    int _crntQueenNum;//当前棋盘上有多少皇后
    int *_sln;//皇后在棋盘上的摆放 _sln[i]=j, 表示第i行皇后在第j列

};

#endif // QUEENSTATE_H
