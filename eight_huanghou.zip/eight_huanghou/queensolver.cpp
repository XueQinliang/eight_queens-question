#include "queensolver.h"
QueenSolver::QueenSolver(int size){
    this->_size=size;
}
QueenSolver::~QueenSolver(){

}
