#include "queenstate.h"
#include "stdio.h"
#include "cstdlib"
QueenState::QueenState(int size){
    this->_size=size;
    this->_crntQueenNum=0;
    int *a=new int[size]();
    this->_sln=a;
}

QueenState::QueenState(const QueenState &st){
    this->_size=st._size;
    this->_crntQueenNum=st._crntQueenNum;
    int *a=new int[st._size]();
    for(int i=0;i<st._size;i++){
        *(a+i)=st._sln[i];
    }
    this->_sln=a;
}
void QueenState::placeQueen(int i, int j){
    *(_sln+i)=j;
    this->_crntQueenNum++;
}
void QueenState::printState(){
    for(int i=0;i<_size;i++){
        printf("%d ",*(_sln+i)+1);
    }
    printf("\n");
}
int QueenState::getCrntQueenNum(){
    return this->_crntQueenNum;
}
bool QueenState::conflict(int i, int j){
    for(int k=0;k<i;k++){
        if(abs(*(_sln+k)-j)==abs(i-k)||*(_sln+k)==j)
            return true;
    }
    return false;
}

QueenState::~QueenState(){
    delete[] _sln;
}
